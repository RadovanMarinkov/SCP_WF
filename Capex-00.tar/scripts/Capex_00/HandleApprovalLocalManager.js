var decision = {
	"UserId": $.usertasks.usertask4.last.processor,
	"Role": "Local Manager",
	"Action": $.usertasks.usertask4.last.decision,
	"Comment": $.context.comment
};

$.context.History.push(decision);
$.context.comment = "";

$.context.decision = $.usertasks.usertask4.last.decision;